=== Finest Floating Cart for WooCommerce ===

Plugin Name: Floating Cart for WooCommerce
Contributors: FinestDevs, ashrafuddin765
Author: FinestDevs
Author URI: https://finestdevs.com
Tags: woocommerce cart, side cart, fly to cart, fly cart, woocommerce side cart, mini cart, floating cart, cart, ajax cart, ajax add to cart, related products, upsell, cross-sell, finest floating cart
Requires at least: 4.6
Tested up to: 6.2.3
Stable tag: 2.6.9
Requires PHP: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enhance your customers' shopping experience and boost conversions. A powerful plugin for creating a seamless and intuitive checkout process on your online store.

== Description ==

Floating Cart for WooCommerce is the ultimate solution for increasing sales and boosting conversions on your online store.

<a target="_blank" href="https://plugins.finestdevs.com/floatingcart">👉 **Check Live Preview**</a>

Are you tired of losing potential customers due to a clunky and inconvenient checkout process? With our floating cart feature, you'll never have to worry about lost sales again.

When customers are browsing your store, they might add items to their cart but then abandon the purchase when they're ready to checkout.

This can be due to a variety of reasons, such as a complicated checkout process, slow loading times, or a lack of trust in your store.

Floating Cart for WooCommerce solves all of these problems by providing a seamless and intuitive shopping experience for your customers.

With a floating cart icon always visible on every page of your store, your customers can easily access their cart and see what they've added at a glance. And when they're ready to checkout, a sliding cart will appear with all of their items, making it easy for them to review and complete their purchase.

Enhance your customers' shopping experience and boost conversions. A powerful plugin for creating a seamless and intuitive checkout process on your online store.

**Check Video Demo**

[youtube https://youtu.be/XP31UmttBUg]

**Live Website Demo**

<a target="_blank" href="https://plugins.finestdevs.com/floatingcart">👉 **Check Live Preview**</a>

**What makes our features stand out from the competition?**

**Attractive and user-friendly design:** Our floating cart feature is sleek and modern, with a clean and intuitive interface that's easy for your customers to use.

**Mobile-friendly:** With more and more customers shopping on their phones, it's important that your store is mobile-friendly. Our floating cart feature is fully responsive, so it works seamlessly on any device.

**Increased trust and security:** By providing a secure and trustworthy checkout process, you can increase your customers' confidence in your store and reduce the risk of abandoned carts.

**Easy customization:** You can easily customize the look and feel of your floating cart to match your store's branding and design.

**Time-saving:** With our floating cart feature, your customers don't have to navigate to a separate page to complete their purchase. This saves them time and makes the checkout process quicker and more convenient.

By using Floating Cart for WooCommerce plugin, you'll be able to provide a superior shopping experience for your customers and increase conversions on your store.

So why wait? Try our floating cart feature today and start seeing results!

<a target="_blank" href="https://plugins.finestdevs.com/floatingcart">👉 **Check Live Preview**</a>


**Why should you use this plugin?**

All our features are available in the free version. More features will be added soon. 

- 2 Types of Floating Cart Styles
- 6 Different Cart Position Change Options
- Ajax Floating Cart, No More Page Loading
- Live Preview Customizer
- Custom Colors / Backgrounds
- 100% Customizable Elements
- Change Cart Width / Height
- Quick Add to Cart
- Update Quantity on Cart
- Remove Items from Cart
- Enable Coupon Code
- Enable Shipping Fee
- Different Device Visibility Options
- Fully Translatable
- Display Subtotal or Total
- 100% Responsive / Mobile & Tablet Support
- 1000+ Free Fonts
- Automated Updates & Security Patches
- Priority Email & Help Center Support


**Translations**

- English - default

*Note:* All our plugins are localized / translatable by default.

== Installation ==

Installing "Floating Cart for WooCommerce" can be done by following these steps:

1. Download the plugin from your WordPress dashboard or from **https://wordpress.org/plugins/finest-mini-cart/**
2. Upload the plugin ZIP file through the 'Plugins > Add New > Upload'  in your WordPress dashboard.
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

#### V.1.0.4 - 17.08.2023
- **Fixed**: Shipping callculation issue.

#### V.1.0.3 - 2.03.2023
- **Fixed**: Minor CSS/JS issues on Cart Area

#### V.1.0.2 - 26.12.2022
- **Fixed**: Minor CSS issues on Cart Area

#### V.1.0.1 - 26.12.2022
- **New**: Redesiged version of the whole plugin experience
- **Fixed**: Minor CSS issues on several parts

#### V.1.0.0 - 14.06.2022
- **Initial**: Initial Version